# Hallucination Fix - Quick Reference

## What Changed

### Before (False Positives)
```
Chunk: "the... the entrance" (reference has repetition)
Result: ❌ FAIL - Hallucination detected
Problem: Validator ignores reference context
```

### After (Context-Aware)
```
Chunk: "the... the entrance" (reference has repetition)
Result: ✅ PASS - No hallucination (reference also repeats)
Fix: Validator compares ref vs hyp repetition counts
```

## Key Improvements

### 1. Context-Aware Detection
- Only flags repetitions if **hypothesis > reference**
- Strips punctuation for fair comparison
- Classifies severity: minor, moderate, severe

### 2. Tolerance Policy
- Minor hallucinations with score ≥ 0.95 → PASS (with warning)
- Severe hallucinations → always FAIL
- Truncation → always FAIL

## Quick Test

```bash
# Run the test suite
python3 test_hallucination_detection.py

# Expected: All 12 tests pass
# - 8 context-aware detection tests
# - 4 tolerance policy tests
```

## Configuration

### Tolerance Threshold (Line ~38)
```python
PASS_TOLERANCE_SCORE = 0.95  # 95% score required for tolerance

# More lenient:
PASS_TOLERANCE_SCORE = 0.90

# More strict:
PASS_TOLERANCE_SCORE = 0.98
```

### Severity Thresholds (Line ~570)
```python
# Current:
if hyp_count >= 4 or excess >= 3:  # Severe
elif hyp_count == 3 or excess == 2:  # Moderate
else:  # Minor

# Adjust based on your needs
```

## Expected Results

### Chunks That Should Now Pass

| Chunk | Issue | Why It Now Passes |
|-------|-------|-------------------|
| 00203 | `"the... the"` | Reference has repetition |
| 00666 | `"No, no, no..."` | Score 1.00 + minor → tolerance |
| 00761 | `"really, really"` | Reference has repetition |
| 01237 | `"Mr. Mr."` | Score 0.99 + minor → tolerance |
| 01636 | `"Go! Go!"` | Reference has repetition |
| 02722 | `"Mohini" (2x)` | Reference has repetition |
| 03533 | `"go go go"` | Reference has repetition |

**Total:** ~8 out of 24 failures should now pass

### Chunks That Still Fail (Correctly)

| Chunk | Issue | Why It Still Fails |
|-------|-------|-------------------|
| 02684 | `Hope! Hope! Hope! Hope!` | Severe (4x vs 1x) |
| 00382 | Extra `What?` | Legitimate repetition issue |

## Diagnostic Output Format

### Before
```
Hallucination: 'the' repeated 2 times (type: single_word)
```

### After
```
Hallucination: 'the' repeated 2 times in hypothesis 
(vs 2 in reference, type: single_word, severity: minor)
```

**Better visibility:** Shows reference count for context

## Decision Tree

```
┌─ Is Truncated? ────────────────────────────────────┐
│   YES → FAIL (always)                              │
└────────────────────────────────────────────────────┘
                    ↓ NO
┌─ Is Severe Hallucination? ─────────────────────────┐
│   YES → FAIL (always)                              │
└────────────────────────────────────────────────────┘
                    ↓ NO
┌─ Is Minor Hallucination + Score >= 0.95? ──────────┐
│   YES → PASS (tolerance applied)                   │
└────────────────────────────────────────────────────┘
                    ↓ NO
┌─ Score >= Threshold? ──────────────────────────────┐
│   YES → PASS                                       │
│   NO  → FAIL                                       │
└────────────────────────────────────────────────────┘
```

## Troubleshooting

**Q: Still seeing false positives?**
A: Lower `PASS_TOLERANCE_SCORE` or adjust severity thresholds

**Q: Too many chunks passing?**
A: Raise `PASS_TOLERANCE_SCORE` to 0.98

**Q: What counts as "severe"?**
A: 4+ repeats OR 3+ excess repeats compared to reference

**Q: Can I disable tolerance?**
A: Set `PASS_TOLERANCE_SCORE = 1.0` (requires perfect score)

## Files

- `asr_validator.py` - Main implementation
- `test_hallucination_detection.py` - Unit tests
- `HALLUCINATION_FIX_SUMMARY.md` - Detailed documentation
- `HALLUCINATION_QUICK_REF.md` - This file

---

**Status:** Tested and ready for production use  
**Impact:** ~33% reduction in false positive failures
