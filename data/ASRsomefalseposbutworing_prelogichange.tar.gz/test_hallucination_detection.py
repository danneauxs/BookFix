#!/usr/bin/env python3
"""
Test script for the updated context-aware hallucination detection.
Tests the scenarios from the fail log to ensure false positives are eliminated.
"""

def normalize_for_comparison(text):
    """Strip punctuation for fair comparison"""
    import re
    return re.sub(r'[^\w\s]', '', text.lower())

def count_max_adjacent_repeats(text):
    """Count maximum adjacent repetitions of words and phrases in text"""
    # Normalize text for fair comparison
    normalized = normalize_for_comparison(text)
    tokens = normalized.split()
    
    if len(tokens) < 2:
        return {}, {}
    
    # Single word repetitions
    word_repeats = {}
    current_word = tokens[0]
    current_count = 1
    
    for token in tokens[1:]:
        if token == current_word:
            current_count += 1
        else:
            if current_count >= 2:
                word_repeats[current_word] = max(
                    word_repeats.get(current_word, 0), 
                    current_count
                )
            current_word = token
            current_count = 1
    
    # Check last word
    if current_count >= 2:
        word_repeats[current_word] = max(
            word_repeats.get(current_word, 0), 
            current_count
        )
    
    # Phrase repetitions (2-word sequences)
    phrase_repeats = {}
    for i in range(len(tokens) - 1):
        phrase = f"{tokens[i]} {tokens[i+1]}"
        count = 1
        j = i + 1
        while j < len(tokens) - 1:
            next_phrase = f"{tokens[j]} {tokens[j+1]}"
            if next_phrase == phrase:
                count += 1
                j += 1
            else:
                break
        if count >= 2:
            phrase_repeats[phrase] = max(phrase_repeats.get(phrase, 0), count)
    
    return word_repeats, phrase_repeats

def detect_hallucination(ref_text, hyp_text):
    """Context-aware hallucination detection"""
    ref_word_repeats, ref_phrase_repeats = count_max_adjacent_repeats(ref_text)
    hyp_word_repeats, hyp_phrase_repeats = count_max_adjacent_repeats(hyp_text)
    
    # Check for hallucinated word repetitions
    for word, hyp_count in hyp_word_repeats.items():
        ref_count = ref_word_repeats.get(word, 0)
        
        if hyp_count > ref_count:
            excess = hyp_count - ref_count
            
            if hyp_count >= 4 or excess >= 3:
                severity = "severe"
            elif hyp_count == 3 or excess == 2:
                severity = "moderate"
            else:
                severity = "minor"
            
            return {
                "is_hallucination": True,
                "pattern": word,
                "count": hyp_count,
                "ref_count": ref_count,
                "type": "single_word",
                "severity": severity
            }
    
    # Check for hallucinated phrase repetitions
    for phrase, hyp_count in hyp_phrase_repeats.items():
        ref_count = ref_phrase_repeats.get(phrase, 0)
        
        if hyp_count > ref_count:
            return {
                "is_hallucination": True,
                "pattern": phrase,
                "count": hyp_count,
                "ref_count": ref_count,
                "type": "phrase",
                "severity": "severe"
            }
    
    return {"is_hallucination": False}

# Test cases from the fail log
print("=" * 70)
print("TESTING CONTEXT-AWARE HALLUCINATION DETECTION")
print("=" * 70)

test_cases = [
    {
        "name": "Chunk 00203 - 'the the' (legitimate)",
        "ref": '"Because the... the entrance is blocked," Scabs said. "Kind of."',
        "hyp": 'Because the the entrance is blocked scab said kind of',
        "expected": "NO HALLUCINATION (reference also has 'the the')"
    },
    {
        "name": "Chunk 00666 - 'no, no' repeated (legitimate)",
        "ref": 'He ran his hands over the boy\'s face and neck. "No, no," whispered. "No, no, no..."',
        "hyp": 'He ran his hands over the boy\'s face and neck.  No, no, whispered.  No, no, no, no.',
        "expected": "MINOR HALLUCINATION (hyp has 4 vs ref has 3)"
    },
    {
        "name": "Chunk 00761 - 'really really' (legitimate)",
        "ref": 'No, I\'d love to blast those things to pieces. But they might leave the old medical supplies alone. I know you\'re not from around here, but nothing new gets made anymore. Except really, really bad moonshine.',
        "hyp": 'No, I\'d love to blast those things to pieces, but they might leave the old medical supplies  alone.  I know you\'re not from around here, but nothing new gets made anymore.  Except really really bad moonshine.',
        "expected": "NO HALLUCINATION (reference also has 'really really')"
    },
    {
        "name": "Chunk 01237 - 'Mr. Mr.' (extra repeat)",
        "ref": '"Well, it can be massaged, certainly," Ogden said. "Mr. Ambassador, we\'re sorry..."',
        "hyp": 'Well, it can be massaged, certainly," Ogden said.  Mr.  Mr.  Ambassador, we\'re sorry...',
        "expected": "MINOR HALLUCINATION (hyp has 2 vs ref has 1)"
    },
    {
        "name": "Chunk 01636 - 'Go! Go!' (legitimate)",
        "ref": 'Zola shoved her the rest of the way in, knocking her to the floor and landing on top of her. "Go! Go!',
        "hyp": 'Zola shoved her the rest of the way in, knocking her to the floor and landing on top of her.  Go! Go!',
        "expected": "NO HALLUCINATION (reference also has 'Go! Go!')"
    },
    {
        "name": "Chunk 02684 - 'Hope!' repeated 4x (true hallucination)",
        "ref": '"Hope—" Colt began, feeling annoyed.',
        "hyp": 'Hope!  Hope!  Hope!  Hope!  Culp began, feeling annoyed.',
        "expected": "SEVERE HALLUCINATION (hyp has 4 vs ref has 1)"
    },
    {
        "name": "Chunk 02722 - 'Mohini' repeated (legitimate)",
        "ref": '"That\'s nice. I like how it rolls off my tongue. \'Mohini. \' \'Mo-hi-ni. \' Does it mean anything? Like, secretly?"',
        "hyp": 'That\'s nice. I like how it rolls off my tongue  Mohini  Mohini does it mean anything like?  secretly',
        "expected": "NO HALLUCINATION (reference also has 'Mohini' twice)"
    },
    {
        "name": "Chunk 03533 - 'go go go' (legitimate)",
        "ref": '"Go go go! " Colt shouted, while firing another burst...',
        "hyp": 'Go, go, go, Colt shouted while firing another burst...',
        "expected": "NO HALLUCINATION (reference has 3, hyp has 3)"
    }
]

for i, test in enumerate(test_cases, 1):
    print(f"\n{i}. {test['name']}")
    print("-" * 70)
    result = detect_hallucination(test["ref"], test["hyp"])
    
    if result["is_hallucination"]:
        print(f"   Result: HALLUCINATION DETECTED")
        print(f"   Pattern: '{result['pattern']}'")
        print(f"   Hyp count: {result['count']}, Ref count: {result['ref_count']}")
        print(f"   Type: {result['type']}, Severity: {result['severity']}")
    else:
        print(f"   Result: NO HALLUCINATION")
    
    print(f"   Expected: {test['expected']}")
    
    # Determine if test passes
    is_correct = (
        (not result["is_hallucination"] and "NO HALLUCINATION" in test["expected"]) or
        (result["is_hallucination"] and "HALLUCINATION" in test["expected"])
    )
    
    print(f"   Status: {'✅ PASS' if is_correct else '❌ FAIL'}")

print("\n" + "=" * 70)
print("TOLERANCE POLICY TEST")
print("=" * 70)

# Test tolerance policy
PASS_TOLERANCE_SCORE = 0.95

tolerance_tests = [
    {
        "name": "High score (1.00) with minor hallucination",
        "score": 1.00,
        "severity": "minor",
        "threshold": 0.75,
        "expected": "PASS (tolerance applied)"
    },
    {
        "name": "High score (0.99) with minor hallucination",
        "score": 0.99,
        "severity": "minor",
        "threshold": 0.75,
        "expected": "PASS (tolerance applied)"
    },
    {
        "name": "Medium score (0.90) with minor hallucination",
        "score": 0.90,
        "severity": "minor",
        "threshold": 0.75,
        "expected": "FAIL (below tolerance threshold)"
    },
    {
        "name": "High score (1.00) with severe hallucination",
        "score": 1.00,
        "severity": "severe",
        "threshold": 0.75,
        "expected": "FAIL (severe hallucination)"
    }
]

for i, test in enumerate(tolerance_tests, 1):
    print(f"\n{i}. {test['name']}")
    print("-" * 70)
    
    allow_minor = (
        test["severity"] == "minor" and 
        test["score"] >= PASS_TOLERANCE_SCORE
    )
    
    if test["severity"] == "severe":
        passed = False
        reason = "Severe hallucination (always fail)"
    elif allow_minor:
        passed = test["score"] >= test["threshold"]
        reason = f"Minor hallucination with score {test['score']} >= {PASS_TOLERANCE_SCORE} (tolerance applied)"
    else:
        passed = False
        reason = f"Score {test['score']} < {PASS_TOLERANCE_SCORE} (no tolerance)"
    
    print(f"   Score: {test['score']}, Severity: {test['severity']}, Threshold: {test['threshold']}")
    print(f"   Result: {'PASS' if passed else 'FAIL'}")
    print(f"   Reason: {reason}")
    print(f"   Expected: {test['expected']}")
    
    is_correct = (
        ("PASS" in test["expected"] and passed) or
        ("FAIL" in test["expected"] and not passed)
    )
    
    print(f"   Status: {'✅ CORRECT' if is_correct else '❌ INCORRECT'}")

print("\n" + "=" * 70)
print("TEST COMPLETE")
print("=" * 70)
