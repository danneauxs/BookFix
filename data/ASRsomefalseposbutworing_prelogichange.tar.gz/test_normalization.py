#!/usr/bin/env python3
"""
Test script for the updated dual-channel normalization.
Tests the three main failure cases without requiring the full ASR stack.
"""

import re
from typing import List, Tuple

# Minimal test implementation of normalize logic
ROMAN_TO_INT = {
    'i': 1, 'ii': 2, 'iii': 3, 'iv': 4, 'v': 5, 'vi': 6, 'vii': 7, 'viii': 8, 'ix': 9, 'x': 10,
}

CANON_LOOKUP = {
    "lead": "lead", "leed": "lead", "led": "lead",
    "colt": "colt", "culp": "colt",  # Example canonicalization
}

def test_normalize(text: str) -> Tuple[str, List[str]]:
    """Simplified normalize for testing"""
    
    # 1. Lowercase
    text = text.lower()

    # 2. Detect and extract ID-like spans
    tokens = text.split()
    id_spans = []
    
    def is_id_candidate(token):
        clean = re.sub(r'[^\w]', '', token)
        has_letters = bool(re.search(r'[a-z]', clean))
        has_digits = bool(re.search(r'\d', clean))
        if has_letters and has_digits:
            return True
        if has_digits and len(clean) >= 4:
            return True
        return False
    
    # Stage 2: Assemble ID spans
    i = 0
    while i < len(tokens):
        if is_id_candidate(tokens[i]):
            span_tokens = [tokens[i]]
            j = i + 1
            
            while j < len(tokens):
                if is_id_candidate(tokens[j]):
                    span_tokens.append(tokens[j])
                    j += 1
                elif tokens[j] in ['-', '–', '—'] and j + 1 < len(tokens) and is_id_candidate(tokens[j + 1]):
                    j += 1
                else:
                    break
            
            if i > 0 and len(tokens[i-1]) <= 3 and re.match(r'^[a-z]+$', tokens[i-1]):
                span_tokens.insert(0, tokens[i-1])
                id_spans.append((i-1, j, span_tokens))
            else:
                id_spans.append((i, j, span_tokens))
            
            i = j
        else:
            i += 1
    
    # 3. Canonicalize IDs
    canonical_ids = []
    for idx, (start, end, span_tokens) in enumerate(id_spans):
        raw_id = ''.join(span_tokens)
        canonical_id = re.sub(r'[^a-z0-9]', '', raw_id)
        canonical_ids.append(canonical_id)
    
    # Rebuild with placeholders
    new_tokens = []
    covered = set()
    for idx, (start, end, span_tokens) in enumerate(id_spans):
        for pos in range(start, end):
            covered.add(pos)
    
    i = 0
    for idx, (start, end, span_tokens) in enumerate(id_spans):
        while i < start:
            if i not in covered:
                new_tokens.append(tokens[i])
            i += 1
        new_tokens.append(f'<ID{idx}>')
        i = end
    
    while i < len(tokens):
        if i not in covered:
            new_tokens.append(tokens[i])
        i += 1
    
    text = ' '.join(new_tokens)
    
    # 4. Remove punctuation
    text = re.sub(r'[^\w\s<>]', '', text)
    
    # 5. Collapse repetitions
    tokens = text.split()
    output = []
    i = 0
    
    while i < len(tokens):
        token = tokens[i]
        count = 1
        j = i + 1
        
        while j < len(tokens) and tokens[j] == token:
            count += 1
            j += 1
        
        if count >= 3:
            output.append(token)
        else:
            output.extend(tokens[i:j])
        
        i = j
    
    normalized_prose = ' '.join(output)
    
    return normalized_prose, canonical_ids


# Test Case 1: ID Mismatch (Chunk 02467)
print("=" * 60)
print("Test 1: ID Mismatch (Chunk 02467)")
print("=" * 60)

ref1 = '"R-KK1418991 is not responding," Simon said. "So I have instructed R-KK1893348 to keep watch on it."'
hyp1 = 'RKK 148991 is not responding, Simon said.  So I have instructed RKK-119-93348 to keep watch on it.'

ref_norm1, ref_ids1 = test_normalize(ref1)
hyp_norm1, hyp_ids1 = test_normalize(hyp1)

print(f"Reference IDs: {ref_ids1}")
print(f"Hypothesis IDs: {hyp_ids1}")
print(f"Reference normalized: {ref_norm1}")
print(f"Hypothesis normalized: {hyp_norm1}")
print()

# Test Case 2: Repetition (Chunk 02684)
print("=" * 60)
print("Test 2: Repetition Collapse (Chunk 02684)")
print("=" * 60)

ref2 = '"Hope—" Colt began, feeling annoyed.'
hyp2 = 'Hope!  Hope!  Hope!  Hope!  Culp began, feeling annoyed.'

ref_norm2, ref_ids2 = test_normalize(ref2)
hyp_norm2, hyp_ids2 = test_normalize(hyp2)

print(f"Reference normalized: {ref_norm2}")
print(f"Hypothesis normalized: {hyp_norm2}")
print(f"Repetition collapsed: {'hope' in hyp_norm2 and hyp_norm2.count('hope') == 1}")
print()

# Test Case 3: Various ID formats
print("=" * 60)
print("Test 3: ID Canonicalization - Various Formats")
print("=" * 60)

test_ids = [
    "R-KK1418991",
    "RKK 1418991",
    "RKK-1418991",
    "r kk 1418991",
    "rkk1418991"
]

canonical_set = set()
for test_id in test_ids:
    _, ids = test_normalize(test_id)
    if ids:
        canonical_set.add(ids[0])
        print(f"{test_id:20} → {ids[0]}")

print(f"\nAll variants canonicalized to same ID: {len(canonical_set) == 1}")
print(f"Canonical form: {list(canonical_set)[0] if canonical_set else 'None'}")
