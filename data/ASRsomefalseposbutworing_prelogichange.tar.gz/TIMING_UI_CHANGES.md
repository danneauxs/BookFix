# ASR Validator - Timing and UI Styling Changes

## Summary

Added elapsed time and ETA display to the validation progress, and updated the log output area with a blue background and bright green text for improved readability.

## Changes Made

### 1. Added Time Formatting Utility

**Location:** `asr_validator.py` (after line 340)

**New Function:**
```python
def format_time(seconds: float) -> str:
    """
    Format elapsed time in seconds to HH:MM:SS format.
    """
    hours = int(seconds // 3600)
    minutes = int((seconds % 3600) // 60)
    secs = int(seconds % 60)
    return f"{hours:02d}:{minutes:02d}:{secs:02d}"
```

**Purpose:** Converts elapsed/ETA seconds into human-readable `HH:MM:SS` format.

### 2. Updated Batch Validation Logic

**Location:** `validate_batch()` function (around line 828-870)

**Changes:**
- Added `start_time = time.time()` before thread pool execution
- Added timing calculation inside the chunk completion loop:
  - `elapsed_time = time.time() - start_time`
  - `avg_time_per_chunk = elapsed_time / i`
  - `eta = avg_time_per_chunk * chunks_remaining`
- Updated status message format:
  ```python
  f"Validated {i} of {total_chunks} chunks | Elapsed: {elapsed_str} | ETA: {eta_str}"
  ```

**ETA Formula:**
```
Average Time Per Chunk = Total Elapsed Time / Chunks Completed
ETA = Average Time Per Chunk × Chunks Remaining
```

This provides a dynamic, self-adjusting estimate that becomes more accurate as more chunks are processed.

### 3. Updated GUI Log Widget Styling

**Location:** `ASRApp.create_widgets()` method (around line 960)

**Changes:**
```python
self.log_text_widget = tk.Text(
    self.status_frame, 
    height=15, 
    width=80, 
    state='disabled', 
    wrap='word',
    bg='blue',              # Blue background
    fg='lime',              # Bright green text
    insertbackground='lime' # Bright green cursor
)
```

**Tag Colors (adjusted for dark background):**
- `info`: lime (bright green)
- `warning`: yellow
- `error`: red
- `success`: cyan

## Visual Changes

### Before
```
[White background, black text]
Status: Validated 5 of 10 chunks...
```

### After
```
[Blue background, lime text]
Status: Validated 5 of 10 chunks | Elapsed: 00:02:30 | ETA: 00:02:30
```

## Example Output

When validating 10 chunks with ~30 seconds each:

```
Validated 1 of 10 chunks | Elapsed: 00:00:30 | ETA: 00:04:30
Validated 2 of 10 chunks | Elapsed: 00:01:00 | ETA: 00:04:00
Validated 3 of 10 chunks | Elapsed: 00:01:30 | ETA: 00:03:30
Validated 4 of 10 chunks | Elapsed: 00:02:00 | ETA: 00:03:00
Validated 5 of 10 chunks | Elapsed: 00:02:30 | ETA: 00:02:30
Validated 6 of 10 chunks | Elapsed: 00:03:00 | ETA: 00:02:00
Validated 7 of 10 chunks | Elapsed: 00:03:30 | ETA: 00:01:30
Validated 8 of 10 chunks | Elapsed: 00:04:00 | ETA: 00:01:00
Validated 9 of 10 chunks | Elapsed: 00:04:30 | ETA: 00:00:30
Validated 10 of 10 chunks | Elapsed: 00:05:00 | ETA: 00:00:00
```

## Testing

### Syntax Check
```bash
python3 -m py_compile asr_validator.py
✅ Passed
```

### Function Test
```bash
python3 test_format_time.py
✅ All test cases passed
```

### GUI Test
```bash
python3 asr_validator.py
# Select Batch Mode
# Choose a TTS folder
# Click "Run Validation"
# Observe blue background with green text
# Observe timing information in status updates
```

## Benefits

### Elapsed Time
- Shows total time spent on validation so far
- Helps users understand processing speed
- Useful for performance monitoring

### ETA (Estimated Time to Arrival)
- Provides estimated time until completion
- Self-adjusting based on actual processing speed
- Becomes more accurate as more chunks are processed
- Helps users plan their time

### UI Styling
- **Blue background + green text** = classic terminal aesthetic
- High contrast improves readability
- Easier to scan log output
- Reduced eye strain during long validations
- Professional appearance

## Technical Details

### Time Calculation Precision
- Uses `time.time()` for wall-clock time (not CPU time)
- Includes all overhead (ASR processing, file I/O, etc.)
- Accurate for real-world user experience
- Updates after each chunk completion

### ETA Accuracy
- **First chunk:** ETA based on single data point (may be inaccurate)
- **After 2-3 chunks:** ETA stabilizes to reasonable estimate
- **After 5+ chunks:** ETA becomes quite accurate
- **Final chunks:** ETA approaches zero smoothly

### Thread Safety
- All timing calculations happen in the main validation thread
- Queue-based communication with GUI (no race conditions)
- Status updates are atomic

## Configuration

### Adjusting Status Update Format

To change the status message format, edit line ~870 in `asr_validator.py`:

```python
# Current format:
"message": f"Validated {i} of {total_chunks} chunks | Elapsed: {elapsed_str} | ETA: {eta_str}"

# Alternative formats:
# Compact:
"message": f"{i}/{total_chunks} | {elapsed_str} | ETA {eta_str}"

# Verbose:
"message": f"Progress: {i} of {total_chunks} chunks complete. Elapsed time: {elapsed_str}. Estimated time remaining: {eta_str}"
```

### Adjusting Log Colors

To change the log widget colors, edit lines ~960-975 in `asr_validator.py`:

```python
# Alternative color schemes:

# Matrix theme (green on black):
bg='black', fg='#00FF00'

# Amber terminal (amber on black):
bg='black', fg='#FFBF00'

# High contrast (white on black):
bg='black', fg='white'

# Solarized dark (cream on dark blue):
bg='#002b36', fg='#839496'
```

## Backward Compatibility

✅ All existing functionality preserved
✅ Log file formats unchanged
✅ CLI behavior unchanged
✅ No new dependencies
✅ Existing validation logic untouched

## Files Modified

1. `asr_validator.py` - Main application
   - Added `format_time()` utility function
   - Updated `validate_batch()` with timing logic
   - Updated `ASRApp.create_widgets()` with new styling

## Testing Checklist

- [x] Syntax validation passes
- [x] Time formatting function tested
- [x] ETA calculation logic verified
- [ ] GUI launches successfully
- [ ] Log area shows blue background
- [ ] Log text shows bright green color
- [ ] Status updates include timing information
- [ ] ETA becomes more accurate over time
- [ ] Completed validation shows 00:00:00 ETA

---

**Implementation Date:** January 22, 2026
**Status:** Complete and ready for testing
**Impact:** User experience improvement (no functional changes to validation logic)
