# Timing & UI Features - Quick Reference

## What You'll See

### Status Message Format
```
Validated X of Y chunks | Elapsed: HH:MM:SS | ETA: HH:MM:SS
```

### Example Progress
```
Validated 1 of 10 chunks  | Elapsed: 00:00:30 | ETA: 00:04:30
Validated 5 of 10 chunks  | Elapsed: 00:02:30 | ETA: 00:02:30
Validated 10 of 10 chunks | Elapsed: 00:05:00 | ETA: 00:00:00
```

## Color Scheme

| Element | Color |
|---------|-------|
| Background | Blue |
| Normal Text | Bright Green (Lime) |
| Info | Lime |
| Warning | Yellow |
| Error | Red |
| Success | Cyan |

## How ETA Works

1. **First chunk:** ETA = rough estimate (may be inaccurate)
2. **After 2-3 chunks:** ETA stabilizes
3. **After 5+ chunks:** ETA is quite accurate
4. **Last chunk:** ETA shows 00:00:00

**Formula:** `ETA = (Elapsed ÷ Completed) × Remaining`

## Benefits

✅ Know exactly how long validation has been running
✅ Estimate when validation will complete
✅ Plan your time accordingly
✅ Easier to read (high contrast colors)
✅ Professional terminal aesthetic

## Quick Test

```bash
# Launch the validator
python3 asr_validator.py

# Or use the launcher
./run.sh

# Select Batch Mode
# Choose a TTS folder
# Click "Run Validation"
# Watch the timing info and enjoy the colors!
```

## Troubleshooting

**Q: Timing not showing?**
A: Ensure you're in Batch Mode (not Chunk Mode)

**Q: Colors look wrong?**
A: Check your terminal/display color settings

**Q: ETA seems inaccurate at start?**
A: Normal - it stabilizes after a few chunks

**Q: Want to change colors?**
A: Edit `asr_validator.py` around line 960

## Code Locations

- **Time formatting:** Line ~340 (`format_time()`)
- **Timing logic:** Line ~830-870 (`validate_batch()`)
- **Color styling:** Line ~960-975 (`create_widgets()`)

---

**Enjoy your improved validation experience!** 🎉
