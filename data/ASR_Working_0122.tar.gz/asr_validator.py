#!/usr/bin/env python3
"""
ASR Validation Tool - Standalone Tkinter GUI
Validates TTS-generated audio chunks using ASR and compares to reference text.
Generates validation.log and fail.log reports.

SELF-CONTAINED VERSION - No external dependencies on modules/
Uses faster-whisper for ASR transcription
"""

import tkinter as tk
from tkinter import filedialog, messagebox, ttk
import os
import sys
import json
import logging
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Dict, List, Tuple, Optional, Any
import threading
import queue
import re
import time

# ASR/Similarity related imports
import rapidfuzz.fuzz as fuzz
import torch
import librosa

# Set up basic logging for the standalone app
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# ============================================================================
# CONFIGURATION CONSTANTS
# ============================================================================

DEFAULT_ASR_MODEL = "tiny"
ASR_SAFETY_BUFFER_MB = 500

# ASR Model Memory Requirements (MB)
ASR_MODEL_VRAM_MB = {
    "tiny": 39,
    "base": 74,
    "small": 244,
    "medium": 769,
    "large": 1550,
    "large-v2": 1550,
    "large-v3": 1550
}

# ============================================================================
# ROMAN NUMERAL MAPPING
# ============================================================================

ROMAN_TO_INT = {
    'i': 1, 'ii': 2, 'iii': 3, 'iv': 4, 'v': 5, 'vi': 6, 'vii': 7, 'viii': 8, 'ix': 9, 'x': 10,
    'xi': 11, 'xii': 12, 'xiii': 13, 'xiv': 14, 'xv': 15, 'xvi': 16, 'xvii': 17, 'xviii': 18, 'xix': 19, 'xx': 20,
    'xxi': 21, 'xxii': 22, 'xxiii': 23, 'xxiv': 24, 'xxv': 25, 'xxx': 30, 'xl': 40, 'l': 50,
    'lx': 60, 'lxx': 70, 'lxxx': 80, 'xc': 90, 'c': 100
}

# ============================================================================
# PRONUNCIATION CANONICALIZATION
# ============================================================================

PRONUNCIATION_CANONICALIZATION = {
    "jesus": ["jesus", "heysous"],
    "lead": ["leed", "led"],
    "tear": ["teer", "tair"],
    "bow": ["bau", "bo"],
    "wind": ["wynd", "wined"],
    "minute": ["mynoot", "minit"],
    "object": ["ubjekt", "objekt"],
    "read": ["reed", "red"],
    "row": ["rau", "ro"],
    "bass": ["base", "bass"],
    "alternate": ["awlturnate", "allturnit"],
    "refuse": ["refuze", "refuse"],
    "polish": ["pole-ish", "pollish"],
    "invalid": ["in-valid", "invalid"],
    "wound": ["woond", "wow'nd"],
    "live": ["lyve", "liv"],
    "resume": ["rezoom", "rezzoomay"],
    "breath": ["breth", "breethe"],
    "prepositioned": ["pre-positioned", "prepisitioned"],
    "close": ["cloze", "close"],
    "sow": ["soh", "sau"],
    "present": ["prezent", "present"],
    "elaborate": ["elaboreight", "elaborit"],
    "estimate": ["estimeight", "estimit"],
    "recreation": ["re-kreation", "reck-reation"],
}

# Build variant → canonical lookup
CANON_LOOKUP = {}
for canonical, variants in PRONUNCIATION_CANONICALIZATION.items():
    CANON_LOOKUP[canonical] = canonical
    for variant in variants:
        CANON_LOOKUP[variant] = canonical

# ============================================================================
# NORMALIZATION
# ============================================================================

def normalize(text: str, canon_lookup: dict = None) -> str:
    """
    Normalize text for comparison:
    - lowercase
    - expand contractions (what're → what are)
    - convert digits to words (2 → two, 14 → fourteen)
    - remove punctuation except hyphens and apostrophes
    - collapse whitespace
    - canonicalize pronunciation variants
    - return space-separated tokens
    """
    from num2words import num2words

    if canon_lookup is None:
        canon_lookup = CANON_LOOKUP

    # Lowercase
    text = text.lower()

    # Expand common contractions BEFORE digit conversion
    contraction_map = {
        "what're": "what are",
        "we're": "we are",
        "you're": "you are",
        "they're": "they are",
        "that's": "that is",
        "it's": "it is",
        "don't": "do not",
        "can't": "cannot",
        "won't": "will not",
        "i'll": "i will",
        "you'll": "you will",
        "he'll": "he will",
        "she'll": "she will",
        "we'll": "we will",
        "they'll": "they will",
        "i've": "i have",
        "you've": "you have",
        "we've": "we have",
        "they've": "they have",
        "i'm": "i am",
        "you're": "you are",
        "we're": "we are",
        "they're": "they are",
        "tony'll": "tony will",  # From your chunk_01264
    }

    for contraction, expansion in contraction_map.items():
        text = text.replace(contraction, expansion)

    # Convert Roman numerals to digits BEFORE digit-to-word conversion
    # This handles: "chapter x" → "chapter 10", "part ii" → "part 2"
    tokens = text.split()
    for i, token in enumerate(tokens):
        if token in ROMAN_TO_INT:
            tokens[i] = str(ROMAN_TO_INT[token])
    text = ' '.join(tokens)

    # Convert digits to words (standalone numbers only)
    def digit_to_word(match):
        try:
            num = int(match.group())
            return num2words(num, lang='en')
        except:
            return match.group()

    text = re.sub(r'\b\d+\b', digit_to_word, text)

    # Remove punctuation except hyphens and apostrophes
    text = re.sub(r'[^\w\s\'-]', '', text)

    # Collapse whitespace
    text = re.sub(r'\s+', ' ', text).strip()

    # Split into tokens and canonicalize pronunciation variants
    tokens = text.split()
    tokens = [canon_lookup.get(t, t) for t in tokens]

    return ' '.join(tokens)

# ============================================================================
# SIMILARITY
# ============================================================================

def similarity(a: str, b: str) -> float:
    """
    Calculate similarity ratio between two normalized strings.
    """
    return fuzz.ratio(a, b) / 100.0

# ============================================================================
# DIFF EXPLANATION
# ============================================================================

def explain_diff(ref: str, hyp: str) -> str:
    """
    Generate human-readable explanation for similarity failure.
    """
    ref_tokens = set(ref.split())
    hyp_tokens = set(hyp.split())

    missing = ref_tokens - hyp_tokens
    extra = hyp_tokens - ref_tokens

    if missing and extra:
        return f"missing: {', '.join(sorted(missing))}; extra: {', '.join(sorted(extra))}"
    elif missing:
        return f"missing words: {', '.join(sorted(missing))}"
    elif extra:
        return f"extra words: {', '.join(sorted(extra))}"
    else:
        return "high edit distance or word order differences"

# ============================================================================
# FILE DISCOVERY
# ============================================================================

def discover_chunks(tts_dir: Path) -> List[str]:
    """
    Find all matching audio/text chunk pairs.
    Returns sorted list of chunk identifiers (e.g., "chunk_00001")
    """
    audio_dir = tts_dir / "audio_chunks"
    text_dir = tts_dir / "text_chunks"

    if not audio_dir.exists() or not text_dir.exists():
        return []

    audio_chunks = set()
    text_chunks = set()

    for f in audio_dir.glob("chunk_*.wav"):
        num = f.stem  # "chunk_00001"
        audio_chunks.add(num)

    for f in text_dir.glob("chunk_*.txt"):
        num = f.stem
        text_chunks.add(num)

    # Return intersection (chunks that have both)
    return sorted(audio_chunks & text_chunks)

# ============================================================================
# ASR MODEL MANAGEMENT
# ============================================================================

def get_real_time_vram_status():
    """Get current GPU memory usage in real-time"""
    try:
        if torch.cuda.is_available():
            gpu_count = torch.cuda.device_count()
            if gpu_count > 0:
                # Use first GPU
                total_vram = torch.cuda.get_device_properties(0).total_memory
                allocated_vram = torch.cuda.memory_allocated(0)
                reserved_vram = torch.cuda.memory_reserved(0)
                available_vram = total_vram - allocated_vram

                return {
                    'total_mb': total_vram // 1024 // 1024,
                    'allocated_mb': allocated_vram // 1024 // 1024,
                    'reserved_mb': reserved_vram // 1024 // 1024,
                    'available_mb': available_vram // 1024 // 1024,
                    'has_gpu': True
                }
    except Exception as e:
        logging.warning(f"Failed to get real-time VRAM status: {e}")

    return {
        'total_mb': 0,
        'allocated_mb': 0,
        'reserved_mb': 0,
        'available_mb': 0,
        'has_gpu': False
    }

def calculate_available_vram_for_asr(safety_buffer_mb=500):
    """Calculate VRAM available for ASR with safety buffer"""
    vram_status = get_real_time_vram_status()

    if not vram_status['has_gpu']:
        return 0

    # Available VRAM minus safety buffer for stability
    available_with_buffer = max(0, vram_status['available_mb'] - safety_buffer_mb)

    return available_with_buffer

def can_model_fit_gpu(model_name, available_vram_mb):
    """Check if a specific ASR model can fit in available VRAM"""
    required_vram = ASR_MODEL_VRAM_MB.get(model_name, 0)
    return available_vram_mb >= required_vram

def load_asr_model_adaptive():
    """
    Adaptive ASR model loading with real-time VRAM checking and intelligent fallback
    Uses faster-whisper for improved performance

    Returns:
        tuple: (asr_model, actual_device_used) or (None, None) if all loading fails
    """
    from faster_whisper import WhisperModel

    print(f"🔍 Starting adaptive ASR model loading (faster-whisper)...")

    # Get current VRAM status
    vram_status = get_real_time_vram_status()
    available_vram = calculate_available_vram_for_asr()

    print(f"🖥️ Real-time VRAM status:")
    print(f"   Total: {vram_status['total_mb']:,}MB")
    print(f"   Allocated: {vram_status['allocated_mb']:,}MB")
    print(f"   Available for ASR: {available_vram:,}MB (with 500MB safety buffer)")

    # Choose device based on real-time VRAM availability
    if vram_status['has_gpu'] and can_model_fit_gpu(DEFAULT_ASR_MODEL, available_vram):
        device = 'cuda'
        compute_type = 'float16'
        device_display = 'GPU'
        print(f"✅ Using GPU for {DEFAULT_ASR_MODEL}")
    else:
        device = 'cpu'
        compute_type = 'int8'
        device_display = 'CPU'
        print(f"🔄 Using CPU for {DEFAULT_ASR_MODEL}")

    try:
        asr_model = WhisperModel(DEFAULT_ASR_MODEL, device=device, compute_type=compute_type)
        print(f"✅ Successfully loaded {DEFAULT_ASR_MODEL} on {device_display}")
        return asr_model, device_display.lower()
    except Exception as e:
        print(f"❌ Critical failure: Could not load {DEFAULT_ASR_MODEL} on {device}: {e}")

        # Ultimate fallback to CPU if GPU failed
        if device == 'cuda':
            try:
                print(f"🆘 Ultimate fallback: {DEFAULT_ASR_MODEL} on CPU")
                asr_model = WhisperModel(DEFAULT_ASR_MODEL, device='cpu', compute_type='int8')
                print(f"✅ Successfully loaded {DEFAULT_ASR_MODEL} on CPU")
                return asr_model, 'cpu'
            except Exception as cpu_e:
                print(f"❌ Total failure: Could not load {DEFAULT_ASR_MODEL} on any device")
                return None, None

    return None, None

def cleanup_asr_model(asr_model):
    """Clean up ASR model to free memory"""
    if asr_model is not None:
        try:
            del asr_model
            if torch.cuda.is_available():
                torch.cuda.empty_cache()
            print(f"🧹 ASR model cleaned up")
        except Exception as e:
            logging.warning(f"Failed to cleanup ASR model: {e}")

# ============================================================================
# HALLUCINATION & TRUNCATION DETECTION
# ============================================================================

def detect_hallucination(text: str) -> dict:
    """
    Detect repetitive patterns that suggest hallucination.
    Returns: {"is_hallucination": bool, "pattern": str, "count": int}
    """
    tokens = text.split()

    if len(tokens) < 3:
        return {"is_hallucination": False}

    # Check for single word repetition
    max_repeats = 1
    repeat_word = ""
    current_word = tokens[0]
    current_count = 1

    for token in tokens[1:]:
        if token == current_word:
            current_count += 1
            if current_count > max_repeats:
                max_repeats = current_count
                repeat_word = current_word
        else:
            current_word = token
            current_count = 1

    # Check for phrase repetition (2+ words)
    phrases = []
    for i in range(len(tokens) - 1):
        phrase = f"{tokens[i]} {tokens[i+1]}"
        phrases.append(phrase)

    max_phrase_repeats = 1
    repeat_phrase = ""
    for i in range(len(phrases) - 1):
        if phrases[i] == phrases[i+1]:
            current_phrase_count = 2
            j = i + 2
            while j < len(phrases) and phrases[j] == phrases[i]:
                current_phrase_count += 1
                j += 1
            if current_phrase_count > max_phrase_repeats:
                max_phrase_repeats = current_phrase_count
                repeat_phrase = phrases[i]

    # Flag if any repetition >= 2 times
    if max_repeats >= 2:
        return {
            "is_hallucination": True,
            "pattern": repeat_word,
            "count": max_repeats,
            "type": "single_word"
        }
    elif max_phrase_repeats >= 2:
        return {
            "is_hallucination": True,
            "pattern": repeat_phrase,
            "count": max_phrase_repeats,
            "type": "phrase"
        }

    return {"is_hallucination": False}

def detect_truncation(ref_text: str, hyp_text: str) -> dict:
    """
    Detect if ASR transcription seems truncated compared to reference.
    Returns: {"is_truncated": bool, "ref_words": int, "hyp_words": int, "ratio": float}
    """
    ref_words = len(ref_text.split())
    hyp_words = len(hyp_text.split())

    if ref_words == 0:
        return {"is_truncated": False, "ref_words": 0, "hyp_words": hyp_words, "ratio": 1.0}

    ratio = hyp_words / ref_words

    # Flag if transcribed < 40% of expected words
    is_truncated = ratio < 0.4

    return {
        "is_truncated": is_truncated,
        "ref_words": ref_words,
        "hyp_words": hyp_words,
        "ratio": ratio
    }

# ============================================================================
# SINGLE CHUNK VALIDATION
# ============================================================================

def validate_single_chunk(chunk_num: str, tts_dir: Path, threshold: float,
                          canon_lookup: dict, asr_model) -> Dict[str, Any]:
    """
    Validate a single chunk: ASR → normalize → compare → result.
    Uses faster-whisper for transcription.
    """
    audio_path = tts_dir / "audio_chunks" / f"{chunk_num}.wav"
    text_path = tts_dir / "text_chunks" / f"{chunk_num}.txt"

    result_template = {
        "chunk_num": chunk_num,
        "passed": False,
        "score": 0.0,
        "ref_text_raw": "",
        "ref_normalized": "",
        "hyp_text_raw": "",
        "hyp_normalized": "",
        "audio_path": str(audio_path),
        "error": ""
    }

    # --- Robustness Checks ---
    if not audio_path.is_file():
        logging.warning(f"Skipping {chunk_num}: Audio file does not exist: {audio_path}")
        result_template.update({"error": "Audio file does not exist"})
        return result_template

    audio_size = os.path.getsize(audio_path)
    if audio_size == 0:
        logging.warning(f"Skipping {chunk_num}: Audio file is empty (0 bytes): {audio_path}")
        result_template.update({"error": "Audio file is empty (0 bytes)"})
        return result_template

    # Check if audio file is loadable and meets minimum requirements
    try:
        # Use librosa for audio info (compatible with all torchaudio versions)
        audio_data, sr = librosa.load(str(audio_path), sr=None)

        if len(audio_data) == 0:
            logging.warning(f"Skipping {chunk_num}: Audio file has 0 frames: {audio_path}")
            result_template.update({"error": "Audio file has 0 frames"})
            return result_template

        # Check minimum duration (Whisper needs at least ~1 second of audio)
        duration_seconds = len(audio_data) / sr
        min_duration = 0.5  # 500ms minimum
        if duration_seconds < min_duration:
            logging.warning(f"Skipping {chunk_num}: Audio file too short ({duration_seconds:.2f}s < {min_duration}s): {audio_path}")
            result_template.update({"error": f"Audio file too short ({duration_seconds:.2f}s < {min_duration}s)"})
            return result_template

        logging.info(f"Audio file {chunk_num}: {len(audio_data)} samples, {sr}Hz, {duration_seconds:.2f}s duration, {audio_size} bytes")

    except Exception as e:
        logging.error(f"Skipping {chunk_num}: Failed to load audio file {audio_path}: {e}")
        result_template.update({"error": f"Failed to load audio file: {e}"})
        return result_template

    if not text_path.is_file():
        logging.warning(f"Skipping {chunk_num}: Text file does not exist: {text_path}")
        result_template.update({"error": "Text file does not exist"})
        return result_template

    text_size = os.path.getsize(text_path)
    if text_size == 0:
        logging.warning(f"Skipping {chunk_num}: Text file is empty (0 bytes): {text_path}")
        result_template.update({"error": "Text file is empty (0 bytes)"})
        return result_template

    # Read reference text
    try:
        with open(text_path, 'r', encoding='utf-8') as f:
            ref_text = f.read().strip()
    except Exception as e:
        logging.error(f"Failed to read text file for {chunk_num} ({text_path}): {e}")
        result_template.update({"error": f"Failed to read text file: {e}"})
        return result_template

    if not ref_text:
        logging.warning(f"Skipping {chunk_num}: Reference text is empty in {text_path}")
        result_template.update({"error": "Reference text is empty"})
        return result_template

    result_template["ref_text_raw"] = ref_text
    ref_normalized = normalize(ref_text, canon_lookup)
    result_template["ref_normalized"] = ref_normalized

    # Run ASR using faster-whisper
    hyp_text_raw = ""
    try:
        logging.info(f"Starting ASR transcription for {chunk_num} ({audio_path})")

        # faster-whisper returns (segments, info)
        # Use VAD filter to prevent hallucinations
        segments, info = asr_model.transcribe(
            str(audio_path),
            condition_on_previous_text=False,
            vad_filter=True,
            vad_parameters={"min_silence_duration_ms": 500}
        )

        # Combine all segments into single text
        hyp_text_raw = " ".join([seg.text for seg in segments]).strip()
        result_template["hyp_text_raw"] = hyp_text_raw
        logging.info(f"ASR transcription completed for {chunk_num}: '{hyp_text_raw}'")

    except Exception as e:
        logging.error(f"ASR transcription failed for {chunk_num} ({audio_path}): {e}")
        result_template.update({"error": f"ASR transcription error: {e}"})
        return result_template

    hyp_normalized = normalize(hyp_text_raw, canon_lookup)
    result_template["hyp_normalized"] = hyp_normalized

    # Detect hallucinations and truncations for diagnostic purposes
    hallucination_check = detect_hallucination(hyp_text_raw)
    truncation_check = detect_truncation(ref_text, hyp_text_raw)

    if hallucination_check["is_hallucination"]:
        result_template["hallucination_warning"] = (
            f"Hallucination detected: '{hallucination_check['pattern']}' "
            f"repeated {hallucination_check['count']} times "
            f"(type: {hallucination_check['type']})"
        )

    if truncation_check["is_truncated"]:
        result_template["truncation_warning"] = (
            f"Possible truncation: {truncation_check['hyp_words']} words "
            f"vs {truncation_check['ref_words']} expected "
            f"({truncation_check['ratio']:.1%})"
        )

    # Calculate similarity (handle empty cases gracefully)
    score = 0.0
    if not ref_normalized and not hyp_normalized:
        score = 1.0  # Both empty, consider it a perfect match
    elif ref_normalized and not hyp_normalized:
        score = 0.0  # Reference exists, hypothesis is empty, definite fail
    elif not ref_normalized and hyp_normalized:
        score = 0.0  # Hypothesis exists, reference is empty, definite fail
    else:
        score = similarity(ref_normalized, hyp_normalized)

    passed = score >= threshold

    result_template.update({
        "passed": passed,
        "score": score,
        "error": "" if passed else result_template["error"]  # Clear error if it passed despite previous warnings
    })
    return result_template

# ============================================================================
# BATCH VALIDATION
# ============================================================================

def validate_batch(tts_dir: Path, threshold: float, progress_queue: queue.Queue,
                   max_workers: int = 1) -> Dict[str, Any]:
    """
    Validate all chunks in parallel.
    Uses faster-whisper for ASR transcription.
    """
    progress_queue.put({"type": "status", "message": "Discovering chunks..."})
    chunk_nums = discover_chunks(tts_dir)

    if not chunk_nums:
        progress_queue.put({"type": "status", "message": "No matching chunk pairs found."})
        return {"error": "No matching chunk pairs found", "total": 0, "passed": 0, "failed": 0, "results": [], "failed_chunks": []}

    total_chunks = len(chunk_nums)
    progress_queue.put({"type": "status", "message": f"Found {total_chunks} chunks. Loading ASR model..."})

    # Load ASR model
    asr_model, device = load_asr_model_adaptive()
    if not asr_model:
        progress_queue.put({"type": "status", "message": "Failed to load ASR model"})
        return {"error": "Failed to load ASR model", "total": 0, "passed": 0, "failed": 0, "results": [], "failed_chunks": []}

    progress_queue.put({"type": "status", "message": f"ASR model loaded on {device.upper()}. Starting validation..."})

    results = []
    all_passed = []
    all_failed = []
    canon_lookup = CANON_LOOKUP.copy()

    def validate_wrapper(chunk_num):
        return validate_single_chunk(chunk_num, tts_dir, threshold, canon_lookup, asr_model)

    try:
        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            futures = [executor.submit(validate_wrapper, chunk_num) for chunk_num in chunk_nums]

            for i, future in enumerate(as_completed(futures), 1):
                try:
                    result = future.result()
                    results.append(result)

                    if result["passed"]:
                        all_passed.append(result)
                    else:
                        all_failed.append(result)

                    # Update progress
                    progress_queue.put({
                        "type": "progress",
                        "current": i,
                        "total": total_chunks
                    })
                    progress_queue.put({
                        "type": "status",
                        "message": f"Validated {i} of {total_chunks} chunks..."
                    })

                except Exception as e:
                    logging.error(f"Validation error: {e}")

    finally:
        # Cleanup ASR model
        cleanup_asr_model(asr_model)

    return {
        "total": len(results),
        "passed": len(all_passed),
        "failed": len(all_failed),
        "results": results,
        "failed_chunks": all_failed,
    }

# ============================================================================
# TKINTER GUI
# ============================================================================

class ASRApp:
    def __init__(self, root):
        self.root = root
        self.root.title("ASR Validation Tool (faster-whisper)")
        self.root.geometry("800x600")

        self.tts_folder_path = None
        self.progress_queue = queue.Queue()  # For thread-safe updates

        self.create_widgets()
        self.setup_logging_redirect()
        self.process_queue()  # Start checking for queue updates

    def create_widgets(self):
        # Mode selector frame
        mode_frame = ttk.Frame(self.root, padding="5")
        mode_frame.pack(padx=10, pady=5, fill="x")

        ttk.Label(mode_frame, text="Mode:").pack(side="left", padx=5)
        self.mode_var = tk.StringVar(value="Batch Mode")
        self.mode_combo = ttk.Combobox(mode_frame, textvariable=self.mode_var,
                                        values=["Batch Mode", "Chunk Mode"], state="readonly", width=15)
        self.mode_combo.pack(side="left", padx=5)
        self.mode_combo.bind("<<ComboboxSelected>>", self.on_mode_change)

        # Frame for folder selection
        self.folder_frame = ttk.LabelFrame(self.root, text="TTS Folder Selection", padding="10")
        self.folder_frame.pack(padx=10, pady=5, fill="x")

        ttk.Label(self.folder_frame, text="Selected Folder:").grid(row=0, column=0, sticky="w", pady=2)
        self.tts_folder_entry = ttk.Entry(self.folder_frame, width=60, state='readonly')
        self.tts_folder_entry.grid(row=0, column=1, padx=5, pady=2, sticky="ew")
        self.browse_button = ttk.Button(self.folder_frame, text="Browse...", command=self.browse_tts_folder)
        self.browse_button.grid(row=0, column=2, padx=5, pady=2)
        self.folder_frame.grid_columnconfigure(1, weight=1)

        # Chunk list frame (for Chunk Mode)
        self.chunk_frame = ttk.LabelFrame(self.root, text="Select Chunk", padding="10")
        # Don't pack yet - will show/hide based on mode

        chunk_list_frame = ttk.Frame(self.chunk_frame)
        chunk_list_frame.pack(fill="both", expand=True)

        self.chunk_listbox = tk.Listbox(chunk_list_frame, height=8, width=50, exportselection=False)
        self.chunk_listbox.pack(side="left", fill="both", expand=True)

        chunk_scrollbar = ttk.Scrollbar(chunk_list_frame, orient="vertical", command=self.chunk_listbox.yview)
        chunk_scrollbar.pack(side="right", fill="y")
        self.chunk_listbox.config(yscrollcommand=chunk_scrollbar.set)

        self.test_chunk_button = ttk.Button(self.chunk_frame, text="Test Selected Chunk",
                                             command=self.test_selected_chunk, state='disabled')
        self.test_chunk_button.pack(pady=5)

        # Single chunk result frame
        self.chunk_result_frame = ttk.LabelFrame(self.root, text="Result", padding="10")
        # Don't pack yet

        self.chunk_result_text = tk.Text(self.chunk_result_frame, height=6, width=70, wrap='word', state='disabled')
        self.chunk_result_text.pack(fill="both", expand=True)

        # Frame for similarity threshold
        self.threshold_frame = ttk.LabelFrame(self.root, text="Validation Settings", padding="10")
        self.threshold_frame.pack(padx=10, pady=5, fill="x")

        ttk.Label(self.threshold_frame, text="Similarity Threshold:").grid(row=0, column=0, sticky="w", pady=2)
        self.threshold_var = tk.DoubleVar(value=0.75)  # Default threshold
        self.threshold_spinbox = ttk.Spinbox(self.threshold_frame, from_=0.0, to=1.0, increment=0.05,
                                              textvariable=self.threshold_var, width=8, format="%.2f")
        self.threshold_spinbox.grid(row=0, column=1, padx=5, pady=2, sticky="w")
        ttk.Label(self.threshold_frame, text="(0.0 - 1.0)").grid(row=0, column=2, padx=5, pady=2)

        # Run Validation Button (for Batch Mode)
        self.run_button = ttk.Button(self.root, text="Run Validation", command=self.start_validation_thread, state='disabled')
        self.run_button.pack(padx=10, pady=10, fill="x")

        # Status and Log Area
        self.status_frame = ttk.LabelFrame(self.root, text="Status and Output Log", padding="10")
        self.status_frame.pack(padx=10, pady=5, fill="both", expand=True)

        self.status_label = ttk.Label(self.status_frame, text="Ready", relief="sunken", anchor="w")
        self.status_label.pack(fill="x", pady=2)

        self.progress_bar = ttk.Progressbar(self.status_frame, orient="horizontal", length=200, mode="determinate")
        self.progress_bar.pack(fill="x", pady=2)
        self.progress_bar.stop()  # Hide initially

        self.log_text_widget = tk.Text(self.status_frame, height=15, width=80, state='disabled', wrap='word')
        self.log_text_widget.pack(fill="both", expand=True, padx=2, pady=2)

        self.log_scrollbar = ttk.Scrollbar(self.status_frame, command=self.log_text_widget.yview)
        self.log_scrollbar.pack(side="right", fill="y")
        self.log_text_widget['yscrollcommand'] = self.log_scrollbar.set

        # Text widget tags for colored logging
        self.log_text_widget.tag_config('info', foreground='black')
        self.log_text_widget.tag_config('warning', foreground='orange')
        self.log_text_widget.tag_config('error', foreground='red')
        self.log_text_widget.tag_config('success', foreground='green')

    def on_mode_change(self, event=None):
        """Handle mode switch between Batch Mode and Chunk Mode."""
        mode = self.mode_var.get()
        if mode == "Chunk Mode":
            # Show chunk selection widgets (pack after folder frame)
            self.chunk_frame.pack(padx=10, pady=5, fill="both", expand=False, after=self.folder_frame)
            self.chunk_result_frame.pack(padx=10, pady=5, fill="x", after=self.chunk_frame)
            # Hide batch run button
            self.run_button.pack_forget()
            # Populate chunk list if folder already selected
            if self.tts_folder_path:
                self.populate_chunk_list()
        else:
            # Batch Mode - hide chunk widgets
            self.chunk_frame.pack_forget()
            self.chunk_result_frame.pack_forget()
            # Show batch run button (pack after threshold frame)
            self.run_button.pack(padx=10, pady=10, fill="x", after=self.threshold_frame)
            if self.tts_folder_path:
                self.run_button.config(state='normal')

    def populate_chunk_list(self):
        """Populate the chunk listbox with available chunks from the TTS folder."""
        self.chunk_listbox.delete(0, tk.END)
        self.test_chunk_button.config(state='disabled')

        if not self.tts_folder_path:
            return

        chunks = discover_chunks(self.tts_folder_path)
        if chunks:
            for chunk in chunks:
                self.chunk_listbox.insert(tk.END, chunk)
            self.test_chunk_button.config(state='normal')
            self.update_log(f"Found {len(chunks)} chunks in folder.", 'info')
        else:
            self.update_log("No matching audio/text chunk pairs found.", 'warning')

    def test_selected_chunk(self):
        """Test the selected chunk from the listbox."""
        selection = self.chunk_listbox.curselection()
        if not selection:
            messagebox.showwarning("No Selection", "Please select a chunk to test.")
            return

        chunk_num = self.chunk_listbox.get(selection[0])
        self.test_chunk_button.config(state='disabled')
        self.status_label.config(text=f"Testing {chunk_num}...")
        self.progress_bar.config(mode="indeterminate")
        self.progress_bar.start()

        # Run in background thread
        test_thread = threading.Thread(target=self._run_single_chunk_test, args=(chunk_num,))
        test_thread.daemon = True
        test_thread.start()

    def _run_single_chunk_test(self, chunk_num: str):
        """Background thread to run single chunk validation."""
        try:
            self.progress_queue.put({"type": "status", "message": f"Loading ASR model..."})
            asr_model, device = load_asr_model_adaptive()

            if not asr_model:
                self.progress_queue.put({"type": "chunk_result", "success": False,
                                         "message": "Failed to load ASR model"})
                return

            try:
                self.progress_queue.put({"type": "status", "message": f"Transcribing {chunk_num}..."})
                threshold = self.threshold_var.get()

                result = validate_single_chunk(chunk_num, self.tts_folder_path, threshold, CANON_LOOKUP, asr_model)

                # Format result for display
                status = "PASSED" if result["passed"] else "FAILED"
                result_text = f"Chunk: {chunk_num}\n"
                result_text += f"Score: {result['score']:.2f}  Status: {status}\n\n"
                result_text += f"Reference: {result['ref_normalized']}\n\n"
                result_text += f"Transcribed: {result['hyp_normalized']}"

                if result.get("error"):
                    result_text += f"\n\nError: {result['error']}"

                # Write to log file
                log_path = self.tts_folder_path / "chunk_test.log"
                with open(log_path, 'a', encoding='utf-8') as f:
                    f.write(f"\n{'='*60}\n")
                    f.write(f"Timestamp: {time.strftime('%Y-%m-%d %H:%M:%S')}\n")
                    f.write(result_text)
                    f.write(f"\n{'='*60}\n")

                self.progress_queue.put({"type": "chunk_result", "success": True,
                                         "message": result_text, "passed": result["passed"]})
            finally:
                cleanup_asr_model(asr_model)

        except Exception as e:
            logging.exception(f"Single chunk test failed: {e}")
            self.progress_queue.put({"type": "chunk_result", "success": False,
                                     "message": f"Error: {e}"})

    def browse_tts_folder(self):
        folder_path = filedialog.askdirectory(parent=self.root, title="Select TTS Output Folder")
        if folder_path:
            selected_path = Path(folder_path)

            # Auto-correct if user selected a subfolder
            if selected_path.name in ("text_chunks", "audio_chunks"):
                selected_path = selected_path.parent
                self.update_log(f"Auto-selected parent TTS folder: {selected_path}", 'info')

            self.tts_folder_path = selected_path
            self.tts_folder_entry.config(state='normal')
            self.tts_folder_entry.delete(0, tk.END)
            self.tts_folder_entry.insert(0, str(self.tts_folder_path))
            self.tts_folder_entry.config(state='readonly')
            self.run_button.config(state='normal')
            self.update_log(f"Selected TTS Folder: {self.tts_folder_path}", 'info')

            # If in Chunk Mode, populate the chunk list
            if self.mode_var.get() == "Chunk Mode":
                self.populate_chunk_list()
        else:
            self.run_button.config(state='disabled')
            self.update_log("No folder selected.", 'warning')

    def setup_logging_redirect(self):
        # Custom handler to redirect logging to the Tkinter Text widget
        class TextWidgetHandler(logging.Handler):
            def __init__(self, text_widget, queue):
                super().__init__()
                self.text_widget = text_widget
                self.queue = queue
                self.setFormatter(logging.Formatter('%(asctime)s - %(levelname)s - %(message)s'))

            def emit(self, record):
                msg = self.format(record)
                tag = record.levelname.lower()
                self.queue.put({"type": "log", "message": msg, "tag": tag})

        self.log_handler = TextWidgetHandler(self.log_text_widget, self.progress_queue)
        logging.getLogger().addHandler(self.log_handler)
        logging.getLogger().setLevel(logging.INFO)  # Ensure logger captures info and above

    def update_log(self, message, tag='info'):
        self.log_text_widget.config(state='normal')
        self.log_text_widget.insert(tk.END, message + '\n', tag)
        self.log_text_widget.yview(tk.END)
        self.log_text_widget.config(state='disabled')

    def process_queue(self):
        while not self.progress_queue.empty():
            item = self.progress_queue.get_nowait()
            if item["type"] == "status":
                self.status_label.config(text=item["message"])
                self.update_log(item["message"], 'info')
            elif item["type"] == "progress":
                if item["total"] > 0:
                    self.progress_bar.config(mode="determinate", maximum=item["total"], value=item["current"])
                    self.progress_bar.start()  # Ensure it's visible and moving
                else:
                    self.progress_bar.stop()
            elif item["type"] == "log":
                self.update_log(item["message"], item["tag"])
            elif item["type"] == "finished":
                self.run_button.config(state='normal')
                self.browse_button.config(state='normal')
                self.progress_bar.stop()
                self.progress_bar.config(value=0)
                self.status_label.config(text=item["message"])
                self.update_log(item["message"], 'success' if item["success"] else 'error')
            elif item["type"] == "chunk_result":
                # Single chunk test result
                self.progress_bar.stop()
                self.progress_bar.config(mode="determinate", value=0)
                self.test_chunk_button.config(state='normal')
                self.chunk_result_text.config(state='normal')
                self.chunk_result_text.delete(1.0, tk.END)
                self.chunk_result_text.insert(tk.END, item["message"])
                self.chunk_result_text.config(state='disabled')
                if item["success"]:
                    tag = 'success' if item.get("passed", False) else 'warning'
                    self.status_label.config(text="Test complete.")
                    self.update_log(f"Chunk test complete: {'PASSED' if item.get('passed') else 'FAILED'}", tag)
                else:
                    self.status_label.config(text="Test failed.")
                    self.update_log(item["message"], 'error')

        self.root.after(100, self.process_queue)  # Check queue every 100ms

    def start_validation_thread(self):
        if not self.tts_folder_path or not self.tts_folder_path.is_dir():
            messagebox.showerror("Error", "Please select a valid TTS folder.")
            return

        # Check for expected subdirectories
        audio_chunks_dir = self.tts_folder_path / "audio_chunks"
        text_chunks_dir = self.tts_folder_path / "text_chunks"
        if not audio_chunks_dir.is_dir() or not text_chunks_dir.is_dir():
            messagebox.showerror("Error", "Selected folder must contain 'audio_chunks' and 'text_chunks' subdirectories.")
            return

        self.run_button.config(state='disabled')
        self.browse_button.config(state='disabled')
        self.status_label.config(text="Starting validation...")
        self.progress_bar.config(value=0)
        self.progress_bar.start()

        validation_thread = threading.Thread(target=self._run_validation_logic)
        validation_thread.daemon = True  # Allow the thread to exit with the main program
        validation_thread.start()

    def _run_validation_logic(self):
        try:
            if not self.tts_folder_path:
                self.progress_queue.put({"type": "finished", "success": False, "message": "No TTS folder selected"})
                return

            tts_folder = self.tts_folder_path
            threshold = self.threshold_var.get()

            self.progress_queue.put({"type": "status", "message": "Starting batch validation..."})
            validation_results = validate_batch(tts_folder, threshold, self.progress_queue)

            if validation_results.get("error"):
                self.progress_queue.put({"type": "finished", "success": False, "message": f"Validation Failed: {validation_results['error']}"})
                return

            self.progress_queue.put({"type": "status", "message": "Generating reports..."})
            self.generate_validation_log(tts_folder, validation_results["results"])
            self.generate_fail_log(tts_folder, validation_results["failed_chunks"])

            final_message = (f"Validation complete! "
                             f"Total: {validation_results['total']}, "
                             f"Passed: {validation_results['passed']}, "
                             f"Failed: {validation_results['failed']}. "
                             f"Logs saved in {tts_folder}")
            self.progress_queue.put({"type": "finished", "success": True, "message": final_message})

        except Exception as e:
            logging.exception("An unexpected error occurred during validation.")
            self.progress_queue.put({"type": "finished", "success": False, "message": f"An unexpected error occurred: {e}"})

    def generate_validation_log(self, tts_dir: Path, results: List[Dict[str, Any]]):
        log_path = tts_dir / "validation.log"
        with open(log_path, 'w', encoding='utf-8') as f:
            f.write(f"ASR Validation Report for: {tts_dir}\n")
            f.write(f"Timestamp: {time.strftime('%Y-%m-%d %H:%M:%S')}\n")
            f.write("=" * 80 + "\n\n")
            for result in results:
                f.write(f"Chunk: {result['chunk_num']}\n")
                f.write(f"Status: {'PASSED' if result['passed'] else 'FAILED'} (Score: {result['score']:.2f})\n")
                if result.get('error'):
                    f.write(f"Error: {result['error']}\n")
                if result.get('hallucination_warning'):
                    f.write(f"Hallucination: {result['hallucination_warning']}\n")
                if result.get('truncation_warning'):
                    f.write(f"Truncation: {result['truncation_warning']}\n")
                f.write(f"Original Text: {result.get('ref_text_raw', result.get('ref_normalized', 'N/A'))}\n")
                f.write(f"Transcribed Text: {result.get('hyp_text_raw', result.get('hyp_normalized', 'N/A'))}\n")
                f.write("-" * 40 + "\n\n")
        self.progress_queue.put({"type": "status", "message": f"Generated validation.log at {log_path}"})

    def generate_fail_log(self, tts_dir: Path, failed_results: List[Dict[str, Any]]):
        log_path = tts_dir / "fail.log"
        with open(log_path, 'w', encoding='utf-8') as f:
            f.write(f"ASR Failed Chunks Report for: {tts_dir}\n")
            f.write(f"Timestamp: {time.strftime('%Y-%m-%d %H:%M:%S')}\n")
            f.write("=" * 80 + "\n\n")
            if not failed_results:
                f.write("No chunks failed validation below the set threshold.\n")
            for result in failed_results:
                f.write(f"Chunk: {result['chunk_num']}\n")
                f.write(f"Status: FAILED (Score: {result['score']:.2f})\n")
                if result.get('error'):
                    f.write(f"Error: {result['error']}\n")
                if result.get('hallucination_warning'):
                    f.write(f"Hallucination: {result['hallucination_warning']}\n")
                if result.get('truncation_warning'):
                    f.write(f"Truncation: {result['truncation_warning']}\n")
                f.write(f"Original Text: {result.get('ref_text_raw', result.get('ref_normalized', 'N/A'))}\n")
                f.write(f"Transcribed Text: {result.get('hyp_text_raw', result.get('hyp_normalized', 'N/A'))}\n")
                f.write(f"Explanation: {explain_diff(result['ref_normalized'], result['hyp_normalized'])}\n")
                f.write("-" * 40 + "\n\n")
        self.progress_queue.put({"type": "status", "message": f"Generated fail.log at {log_path}"})

# Main execution block
if __name__ == "__main__":
    root = tk.Tk()
    app = ASRApp(root)
    root.mainloop()
