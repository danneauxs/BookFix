# run.sh - Smart Launcher Guide

## Overview

The `run.sh` script is an intelligent launcher that handles **everything** for you:
- ✅ Virtual environment creation
- ✅ Dependency installation
- ✅ Environment activation
- ✅ Application launching

## Features

### 🤖 Fully Automated Setup
- Detects if virtual environment exists
- Creates it automatically (with your permission)
- Installs all dependencies in isolated environment
- No global Python pollution

### 📍 Location-Aware
- Runs from wherever it's located
- Auto-detects script directory
- Works with double-click or command line
- Virtual environment created in same folder

### ⚡ Smart Detection
- Checks Python availability (python3/python)
- Verifies all dependencies are installed
- Re-installs if something is missing
- Shows version information

### 🛡️ User Protection
- **Asks permission** before creating venv
- **Warns about 3GB download** before installing
- Shows what's happening at each step
- Waits for user confirmation before exiting

## Usage

### Method 1: Double-Click (GUI)
Simply double-click `run.sh` in your file manager. The script will:
1. Open in terminal
2. Show status messages
3. Ask for permission if setup needed
4. Launch the application
5. Wait for Enter before closing

### Method 2: Command Line
```bash
cd ASR
./run.sh
```

## First Run Experience

### Step-by-Step Walkthrough

```
╔══════════════════════════════════════════════════════════════════╗
║           ASR Validation Tool - Launcher                         ║
╚══════════════════════════════════════════════════════════════════╝

✅ Running from: /home/user/ASR
✅ Found: Python 3.11.5

🔍 Virtual environment not found

⚠️  SETUP REQUIRED
   This tool needs to create a virtual environment and install
   dependencies (~3GB download, includes PyTorch).

   Location: /home/user/ASR/venv
   Packages: torch, torchaudio, librosa, faster-whisper, rapidfuzz

   Create virtual environment and install dependencies? (y/n): y

📦 Creating virtual environment...
✅ Virtual environment created

🔄 Activating virtual environment...
✅ Virtual environment activated

🔍 Checking dependencies...
⚠️  Dependencies not installed or incomplete

📦 Installing dependencies from requirements.txt...
   This may take 5-10 minutes (downloading ~3GB)

[pip installation output...]

✅ All dependencies installed successfully

🔍 Verifying installation...
✅ torch: 2.1.0
✅ torchaudio: 2.1.0
✅ librosa: 0.10.1
✅ faster-whisper: OK
✅ rapidfuzz: 3.5.2

╔══════════════════════════════════════════════════════════════════╗
║                  🚀 Launching ASR Validator                      ║
╚══════════════════════════════════════════════════════════════════╝

[GUI application opens]

════════════════════════════════════════════════════════════════════
✅ Application closed successfully

Press Enter to exit...
```

## Subsequent Runs

After first setup, running `./run.sh` is much faster:

```
╔══════════════════════════════════════════════════════════════════╗
║           ASR Validation Tool - Launcher                         ║
╚══════════════════════════════════════════════════════════════════╝

✅ Running from: /home/user/ASR
✅ Found: Python 3.11.5

✅ Found existing virtual environment at: venv/

🔄 Activating virtual environment...
✅ Virtual environment activated

🔍 Checking dependencies...
✅ All dependencies OK

🔍 Verifying installation...
✅ torch: 2.1.0
✅ torchaudio: 2.1.0
✅ librosa: 0.10.1
✅ faster-whisper: OK
✅ rapidfuzz: 3.5.2

╔══════════════════════════════════════════════════════════════════╗
║                  🚀 Launching ASR Validator                      ║
╚══════════════════════════════════════════════════════════════════╝

[GUI application opens immediately]
```

## What Gets Created

After first run, your ASR directory will look like this:

```
ASR/
├── asr_validator.py        # Main application
├── requirements.txt        # Dependency list
├── run.sh                  # Smart launcher ⭐
├── README.md               # User guide
├── INSTALL.md              # Installation guide
├── SUMMARY.md              # Technical summary
├── QUICKSTART.txt          # Quick reference
├── RUN_SH_GUIDE.md         # This file
└── venv/                   # Virtual environment (auto-created)
    ├── bin/                # Python executable, activation script
    ├── lib/                # Installed packages (~3GB)
    └── ...
```

## Benefits

### vs. Manual Installation

| Aspect | Manual Setup | run.sh |
|--------|--------------|--------|
| Steps required | 5-6 commands | 1 command |
| Remember venv activation | Yes, every time | No, automatic |
| Permission prompts | No | Yes (safer) |
| Error handling | Manual | Automatic |
| User-friendly | Technical | Beginner-friendly |
| Double-clickable | No | Yes ✅ |

### vs. Global Installation

| Aspect | Global Install | run.sh (venv) |
|--------|---------------|---------------|
| System pollution | High | None |
| Conflicts | Possible | Isolated |
| Cleanup | Difficult | Delete venv/ |
| Disk space | System-wide | 3GB in ASR/ |
| Professional | No | Yes ✅ |

## Troubleshooting

### "Permission denied"
```bash
chmod +x run.sh
./run.sh
```

### "Python not found"
Install Python 3.8+ from https://www.python.org/downloads/

### "Installation failed"
Check:
- Internet connection
- Disk space (~5GB free recommended)
- Python version (3.8+)
- Try manual installation method

### Script doesn't wait for Enter
This is expected behavior in some terminals. The script includes `read` commands to pause, but if your terminal auto-closes, run from command line instead of double-clicking.

### Want to start fresh?
```bash
# Delete virtual environment
rm -rf venv/

# Run again to recreate
./run.sh
```

## Advanced Usage

### Specifying Python Version

Edit `run.sh` line 15-23 to force a specific Python:

```bash
# Force Python 3.10
PYTHON_CMD="python3.10"
```

### Custom Virtual Environment Name

Edit `run.sh` line 43:

```bash
# Use .venv instead of venv
VENV_DIR="$SCRIPT_DIR/.venv"
```

### Skip Verification

Comment out lines 118-135 to skip dependency verification (not recommended).

## Understanding the Script

### Key Sections

1. **Lines 1-12**: Header and directory detection
2. **Lines 14-30**: Python availability check
3. **Lines 33-82**: Virtual environment creation (with permission)
4. **Lines 85-103**: Virtual environment activation
5. **Lines 106-128**: Dependency installation
6. **Lines 131-149**: Verification
7. **Lines 151-170**: Application launch

### Safety Features

- ✅ Always asks permission before creating venv
- ✅ Warns about download size
- ✅ Verifies installation before launching
- ✅ Captures and reports exit codes
- ✅ Pauses before closing (see errors)

## Why This Approach?

### Design Decisions

1. **Permission-based**: User controls what happens (Option B requirement)
2. **Location-aware**: Works from script's directory (requirement #2)
3. **Warning included**: Alerts about 3GB download (requirement #3)
4. **Smart detection**: Auto-setup if needed, skip if ready (requirement #4)
5. **Double-clickable**: Works in GUI file managers (requirement #5)

### User Experience Priority

The script prioritizes:
- Clear, emoji-enhanced messages
- Step-by-step progress indication
- Non-technical language
- Graceful error handling
- Educational output (shows what's happening)

## Comparison to Original

### Original run.sh
- ❌ No virtual environment
- ❌ Global installation
- ⚠️ Asked to install globally
- ⚠️ No location awareness

### Enhanced run.sh
- ✅ Creates virtual environment
- ✅ Isolated installation
- ✅ Asks permission first
- ✅ Location-aware (works anywhere)
- ✅ Warns about download size
- ✅ Double-clickable
- ✅ Comprehensive error handling

## Summary

The `run.sh` script transforms the ASR Validator from a technical tool into a **user-friendly application** that:
- Requires zero Python knowledge
- Handles all setup automatically
- Protects the system with virtual environments
- Provides clear feedback at every step
- Just works with a single double-click

Perfect for both beginners and advanced users!
